<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['producto_id'])) {
    $producto_id = $_POST['producto_id'];

    // Incluir archivo de conexión a la base de datos
    include 'Conexion.php';

    // Consultar el producto desde la base de datos
    $sql = "SELECT * FROM productos WHERE Id = $producto_id";
    $result = mysqli_query($con, $sql);

    // Verificar si se obtuvo correctamente el resultado
    if ($result && mysqli_num_rows($result) > 0) {
        $producto = mysqli_fetch_assoc($result);
        
        // Verificar si el carrito ya existe en la sesión, si no, crearlo
        if (!isset($_SESSION['carrito'])) {
            $_SESSION['carrito'] = array();
        }

        // Crear un identificador único para el producto en el carrito
        $boton_id = 'boton_' . $producto_id;

        // Verificar si el producto ya está en el carrito
        if (isset($_SESSION['carrito'][$boton_id])) {
            // Aumentar la cantidad del producto en el carrito
            $_SESSION['carrito'][$boton_id]['Cantidad']++;
            $_SESSION['carrito'][$boton_id]['Subtotal'] = $_SESSION['carrito'][$boton_id]['PrecioProd'] * $_SESSION['carrito'][$boton_id]['Cantidad'];
        } else {
            // Si el producto no está en el carrito, agregarlo con una cantidad inicial de 1
            $producto_carrito = array(
                'ID_prod' => $producto['Id'],
                'NombreProd' => $producto['Nombre'],
                'MaterialProd' => $producto['Material'],
                'DimensionesProd' => $producto['Dimensiones'],
                'CategoriaProd' => $producto['Categoria'],
                'PrecioProd' => $producto['Precio'],
                'Cantidad' => 1,
                'Subtotal' => $producto['Precio']
            );
            $_SESSION['carrito'][$boton_id] = $producto_carrito;
        }

        // Devolver una respuesta (opcional)
        echo "Producto agregado al carrito";
    } else {
        // Manejar el caso donde no se encontró el producto en la base de datos
        echo "Error: Producto no encontrado en la base de datos";
    }
} else {
    // Manejar el caso donde no se recibió correctamente el producto_id
    echo "Error: No se recibió el ID del producto correctamente";
}
?>