<?php
include("Conexion.php");

if(isset($_POST['id'])) {
    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $material = $_POST['material'];
    $dimensiones = $_POST['dimensiones'];
    $precio = $_POST['precio'];
    $categoria = $_POST['categoria'];
    $imagen = $_POST['imagen'];

    $sql = "UPDATE productos SET Nombre='$nombre', Material='$material', Dimensiones='$dimensiones', Precio='$precio', Categoria='$categoria', Imagen='$imagen' WHERE Id=$id";

    if(mysqli_query($con, $sql)) {
        // Redirigir de vuelta a la página de administrador
        header("Location: Admin.php");
        exit();
    } else {
        echo "Error al actualizar el producto: " . mysqli_error($con);
    }
} else {
    echo "No se recibieron los datos necesarios para la actualización.";
}
?>