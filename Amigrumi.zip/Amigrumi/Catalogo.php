<?php
// Verifica si la sesión está activa
session_start();
if(!isset($_SESSION['usuario']) || empty($_SESSION['usuario'])) {
    // La sesión no está activa, redirige al usuario a la página de inicio de sesión
    header("Location: login.html");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Catalogo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="Catalogo.css?ts=<?=time()?>" />
</head>
<body>
<header>
    <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <input type="checkbox" id="menu-bar" />
        <label class="icon-menu" for="menu-bar"></label>
        <nav class="menu">
            <a href="InicioUsuario.php">Inicio</a>
            <a href="Catalogo.php">Catálogo</a>
            <a href="mailto:claudio36184590@gmail.com">Contacto</a>
            <a>
                <?php
                if (session_status() === PHP_SESSION_NONE) {
                    session_start();
                }
                if (isset($_SESSION['usuario'])) {
                    echo $_SESSION['usuario'];
                } elseif (isset($_SESSION['admin'])) {
                    echo "Admin";
                } else {
                    echo "Invitado";
                }
                ?>
            </a>
            <a href="logout.php">Cerrar Sesión</a>
        </nav>
    </div>
</header>

<section id="banner">
    <img class="img" src="Imagenes/logoami.png" />
    <div class="contenedor">
        <h2>Figuras de crochet</h2>
        <p>Figuras de crochet de cualquier temática, incluso personalizados</p>
    </div>
</section>

<main>
    <h1 class="tit">Catálogo</h1>

    <section class="container">
        <?php
        include("Conexion.php");
        $sql = mysqli_query($con, "SELECT * FROM productos");
        while ($row = mysqli_fetch_array($sql)) {
            ?>
            <div class="card">
                <a href="#">
                    <figure class="image-box" style="background-image: url('<?php echo $row['Imagen'] ?>');"></figure>
                </a>
                <div class="contener">
                    <p><?php echo $row['Nombre'] ?></p>
                    <p><?php echo $row['Material'] ?></p>
                    <p><?php echo $row['Dimensiones'] ?></p>
                    <p><?php echo $row['Precio'] ?></p>
                    <p><?php echo $row['Categoria'] ?></p>
                </div>
                <button class="agregar-carrito" data-product-id="<?php echo $row['Id'] ?>">Agregar al carrito</button>
            </div>
        <?php } ?>
    </section>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Material</th>
                    <th>Dimensiones</th>
                    <th>Subtotal</th>
                    <th>Cantidad</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $total = 0;
                if (isset($_SESSION['carrito'])) {
                    foreach ($_SESSION['carrito'] as $boton_id => $producto) {
                        echo "<tr>";
                        echo "<td>{$producto['NombreProd']}</td>";
                        echo "<td>{$producto['MaterialProd']}</td>";
                        echo "<td>{$producto['DimensionesProd']}</td>";
                        echo "<td>$ {$producto['Subtotal']}</td>";
                        echo "<td>{$producto['Cantidad']}</td>";
                        echo "<td>";
                        echo "<a href='modify.php?action=add&id={$boton_id}' class='nav-link'><i class='fa-solid fa-plus'></i></a> ";
                        echo "<a href='modify.php?action=remove&id={$boton_id}' class='nav-link'><i class='fa-solid fa-minus'></i></a> ";
                        echo "<a href='modify.php?action=delete&id={$boton_id}' class='nav-link'><i class='fa-solid fa-trash'></i></a>";
                        echo "</td>";
                        echo "</tr>";
                        $total += $producto['Subtotal'];
                    }
                } else {
                    echo "<tr><td colspan='5'>El carrito está vacío</td></tr>";
                }
                ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="3"><strong>Total</strong></td>
                    <td><strong>$ <?php echo $total; ?></strong></td>
                    <td></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <div class="botonpagar">
        <a href="generar_pdf.php" class="btn-pdf">Pagar <i class="fa-solid fa-file-pdf"></i></a>
    </div>

</main>

<footer>
    <div class="container">
        <p>&copy; Tu Amigo Amigurumi. Todos los derechos reservados.</p>
        <ul>
            <li><a href="https://www.facebook.com/amigurumiscrochetgdl"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="https://www.instagram.com/tuamigoamigurumi/?hl=es"><i class="fab fa-instagram"></i></a></li>
        </ul>
    </div>
</footer>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const agregarCarritoBtns = document.querySelectorAll('.agregar-carrito');

        agregarCarritoBtns.forEach(btn => {
            btn.addEventListener('click', function(event) {
                event.preventDefault();
                const productId = btn.getAttribute('data-product-id');
                agregarAlCarrito(productId);
            });
        });

        function agregarAlCarrito(productId) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', 'agregar_al_carrito.php');
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function() {
                if (xhr.status === 200) {
                    location.reload();
                } else {
                    console.error('Error al agregar al carrito:', xhr.status);
                }
            };
            xhr.send(`producto_id=${productId}`);
        }
    });
</script>

</body>
</html>