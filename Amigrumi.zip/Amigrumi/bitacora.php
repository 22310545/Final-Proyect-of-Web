<?php

include "Conexion.php";

if (!$con) {
    die("Error en la conexión: " . mysqli_connect_error());
}

$triggers = [
    'after_insert_product' => "
        CREATE TRIGGER IF NOT EXISTS after_insert_product
        AFTER INSERT ON productos
        FOR EACH ROW
        BEGIN
            INSERT INTO bitacora (accion, usuario, sentencia)
            VALUES ('insert', USER(), CONCAT('INSERT INTO productos (Id, Nombre, Material, Dimensiones, Precio, Categoria, Imagen) VALUES (', NEW.Id, ', \"', NEW.Nombre, '\", \"', NEW.Material, '\", \"', NEW.Dimensiones, '\", ', NEW.Precio, ', \"', NEW.Categoria, '\", \"', NEW.Imagen, '\")'));
        END;
    ",
    'after_update_product' => "
        CREATE TRIGGER IF NOT EXISTS after_update_product
        AFTER UPDATE ON productos
        FOR EACH ROW
        BEGIN
            INSERT INTO bitacora (accion, usuario, sentencia)
            VALUES ('update', USER(), CONCAT('UPDATE productos SET Nombre = \"', NEW.Nombre, '\", Material = \"', NEW.Material, '\", Dimensiones = \"', NEW.Dimensiones, '\", Precio = ', NEW.Precio, ', Categoria = \"', NEW.Categoria, '\", Imagen = \"', NEW.Imagen, '\" WHERE Id = ', NEW.Id));
        END;
    ",
    'after_delete_product' => "
        CREATE TRIGGER IF NOT EXISTS after_delete_product
        AFTER DELETE ON productos
        FOR EACH ROW
        BEGIN
            INSERT INTO bitacora (accion, usuario, sentencia)
            VALUES ('delete', USER(), CONCAT('DELETE FROM productos WHERE Id = ', OLD.Id));
        END;
    "
];


foreach ($triggers as $trigger) {
    if (!mysqli_query($con, $trigger)) {
        die("Error al crear el trigger: " . mysqli_error($con));
    }
}

$query = "SELECT * FROM bitacora";
$result = mysqli_query($con, $query);

if (!$result) {
    die('Error en la consulta: ' . mysqli_error($con));
}

// Iniciar sesión para obtener el nombre del usuario
session_start();

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bitácora</title>
    <link rel="stylesheet" href="bitacora.css">
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap");
        @import url("https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap");
    </style>
    <link rel="stylesheet" href="Admin.css">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    />
</head>
<body>
<header>
    <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <nav class="menu">
            <a>
                <?php
                if (isset($_SESSION['usuario'])) {
                    echo $_SESSION['usuario'];
                } elseif (isset($_SESSION['admin'])) {
                    echo "Admin";
                } else {
                    echo "Invitado";
                }
                ?>
            </a>
            <a href="Admin.php">Inicio</a>
            <a href="Usuariosv.php">Usuarios</a>
            <a href="bitacora.php">Bitacora</a>
            <a href="logout.php">Cerrar Sesión</a>
        </nav>
    </div>
</header>

<section id="banner">
    <img class="img" src="Imagenes/logoami.png" alt="center">
    <div class="contenedor"></div>
</section>

<main class="Table">
    <section class="table_header">
        <h1>Bitácora</h1>
    </section>
    <section class="table_body">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Acción</th>
                    <th>Fecha y Hora</th>
                    <th>Usuario</th>
                    <th>Sentencia</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Mostrar los registros de la bitacora
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . $row['id'] . "</td>";
                    echo "<td>" . $row['accion'] . "</td>";
                    echo "<td>" . $row['fecha_hora'] . "</td>";
                    echo "<td>" . $row['usuario'] . "</td>";
                    echo "<td>" . $row['sentencia'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </section>
</main>

<footer>
    <div class="container">
        <p>&copy; Tu Amigo Amigurumi. Todos los derechos reservados.</p>
        <ul>
            <li><a href="https://www.facebook.com/amigurumiscrochetgdl"><i class="fab fa-facebook-f"></i></a></li>
            <li><a href="https://www.instagram.com/tuamigoamigurumi/?hl=es"><i class="fab fa-instagram"></i></a></li>
        </ul>
    </div>
</footer>
</body>
</html>