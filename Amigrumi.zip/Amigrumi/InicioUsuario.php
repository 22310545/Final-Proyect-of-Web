<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Index/Amigurumi</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <style>
      @import url("https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap");
    </style>
    <link rel="stylesheet" href="Index.css" />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    />
  </head>
  <body>
    <header>
      <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <input type="checkbox" id="menu-bar" />
        <label class="icon-menu" for="menu-bar"></label>
        <nav class="menu">
          <a href="InicioUsuario.php">Inicio</a>
          <a href="Catalogo.php">Catalogo</a>
          <a href="mailto:claudio36184590@gmail.com">Contacto</a>
          <a>
            <?php
              session_start();
              if (isset($_SESSION['usuario'])) {
                echo $_SESSION['usuario'];
              } elseif (isset($_SESSION['admin'])) {
                echo "Admin";
              } else {
                echo "Invitado";
              }
            ?>
          </a>
          <a href="logout.php">Cerrar Sesión</a>
        </nav>
      </div>
    </header>

    <section id="baner">
      <img class="img" src="Imagenes/logoami.png" alt="center" />
      <div class="contenedor">
        <h2>Figuras de crochet</h2>
        <p>
          Dicen que está hecho a mano pero en realidad está hecho con el corazón"
        </p>
      </div>
    </section>

    <main>
      <section id="inicio" class="hero">
        <div class="title">
          <h1>Bienvenidos a Tu Amigo Amigurumi</h1>
        </div>
        <div class="image-gallery">
          <div class="image-container">
            <img src="Imagenes/2.jpg" alt="Imagen 2" />
          </div>
          <div class="image-container">
            <img src="Imagenes/4.jpg" alt="Imagen 4" />
          </div>
          <div class="image-container">
            <img src="Imagenes/1.jpg" alt="Imagen 1" />
          </div>
          <div class="image-container">
            <img src="Imagenes/5.jpg" alt="Imagen 5" />
          </div>
          <div class="image-container">
            <img src="Imagenes/3.jpg" alt="Imagen 3" />
          </div>
        </div>
        <div class="hero-text">
          <p>Los mejores productos con la mejor calidad.</p>
          <a href="Catalogo.php" class="btn">Ver Productos</a>
        </div>
      </section>

      <section id="mision-vision" class="mision-vision">
        <div class="card-container">
          <div class="image">
            <img src="Imagenes/10.jpg" alt="Imagen de Misión" />
          </div>
          <div class="card">
            <h2>Nuestra Misión</h2>
            <p>
              Es crear muñecos de crochet únicos y personalizados que despierten
              alegría, creatividad y conexión emocional en personas de todas las
              edades. A través de diseños detallados y hechos a mano con amor,
              buscamos ofrecer productos de alta calidad que se conviertan en
              tesoros atemporales y acompañen a nuestros clientes en sus
              momentos más especiales. Nos comprometemos a utilizar materiales
              sostenibles y técnicas artesanales para promover un consumo
              responsable y apoyar el arte del crochet en nuestra comunidad.
            </p>
          </div>
        </div>
        <div class="card-container reverse">
          <div class="imageesp">
            <img src="Imagenes/11.jpg" alt="Imagen de Visión" />
          </div>
          <div class="card">
            <h2>Nuestra Visión</h2>
            <p>
              Es ser la empresa líder en la creación de muñecos de crochet
              personalizados, reconocida mundialmente por nuestra innovación,
              calidad y compromiso con la sostenibilidad. Aspiramos a inspirar a
              las personas a valorar y apreciar el arte del crochet,
              convirtiendo cada uno de nuestros productos en símbolos de amor,
              creatividad y conexión personal. Queremos crear un legado de
              productos que trasciendan generaciones y se conviertan en parte
              fundamental de la vida y las memorias de nuestros clientes,
              mientras apoyamos a comunidades de artesanos y fomentamos
              prácticas comerciales éticas y responsables.
            </p>
          </div>
        </div>
        <div class="card-container">
          <div class="image">
            <img src="Imagenes/5.jpg" alt="Tercer Imagen" />
          </div>
          <div class="card">
            <h2>¿Qué es un Amigurumi?</h2>
            <p>
              Es una palabra japonesa que significa "peluche tejido" y forma
              parte de la cultura "Kawaii" que se puede definir como: bonito,
              tierno y adorable. Más allá de su uso como juguete, el objetivo
              del amigurumi es alimentar el espíritu del niño que todods
              llevamos dentro. Están hechos con técnica de ganchillo en espiral,
              por lo que el tejido es continuo y existen tantas variedades de
              amigurumi como imagenes. Estas adorables figuritas son objetos de
              apego ligados a conceptos de amistad, complicidad y compañia.
            </p>
          </div>
        </div>
      </section>
    </main>

    <footer>
      <div class="container">
        <p>&copy; Tu Amigo Amigurumi. Todos los derechos reservados.</p>
        <ul>
          <li>
            <a href="https://www.facebook.com/amigurumiscrochetgdl"
              ><i class="fab fa-facebook-f"></i
            ></a>
          </li>
          <li>
            <a href="https://www.instagram.com/tuamigoamigurumi/?hl=es"
              ><i class="fab fa-instagram"></i
            ></a>
          </li>
        </ul>
      </div>
    </footer>
    <script>
      document.addEventListener("DOMContentLoaded", () => {
        const images = document.querySelectorAll(
          ".image-container img, .imageesp img"
        );

        const observer = new IntersectionObserver(
          (entries, observer) => {
            entries.forEach((entry) => {
              if (entry.isIntersecting) {
                entry.target.classList.add("transition");
                observer.unobserve(entry.target); // Deja de observar el elemento una vez que se ha añadido la clase
              }
            });
          },
          {
            threshold: 0.1, // Ajusta el umbral según sea necesario
          }
        );

        images.forEach((img) => {
          observer.observe(img);
        });
      });
    </script>
  </body>
</html>
