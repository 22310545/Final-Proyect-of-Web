<?php
    $server = "localhost";
    $data = "amigrumi";
    $user = "root";
    $pass = "";

    $con = mysqli_connect($server,$user,$pass,$data);
    if(!$con){
        die("Falla en la conexion".mysqli_connect_error());
    }else{
        
    }
?>