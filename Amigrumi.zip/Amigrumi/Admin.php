

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administrador</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Dancing+Script:wght@400..700&display=swap");
        @import url("https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap");
    </style>
    <link rel="stylesheet" href="Admin.css">
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    />
</head>
<body>
<header>
    <div class="contenedor">
        <h1 class="titulo">Tu amigo Amigurumi</h1>
        <input type="checkbox" id="menu-bar">
        <label class="icon-menu" for="menu-bar"></label>
        <nav class="menu">
            <a>
                <?php
                session_start();
                if (isset($_SESSION['usuario'])) {
                    echo $_SESSION['usuario'];
                } elseif (isset($_SESSION['admin'])) {
                    echo "Admin";
                } else {
                    echo "Invitado";
                }
                ?>
            </a>
            <a href="Admin.php">Inicio</a>
            <a href="Usuariosv.php">Usuarios</a>
            <a href="bitacora.php">Bitacora</a>
            <a href="logout.php">Cerrar Sesión</a>
        </nav>
    </div>
</header>

<section id="banner">
    <img class="img" src="Imagenes/logoami.png" alt="center">
    <div class="contenedor">
    </div>
</section>

<br />

<h1 class="titulo2">ADMINISTRADOR</h1>

<main class="Table">
    <section class="form-login">
        <h5>Agregar Producto</h5>
        <br />
        <form action="agregar_producto.php" method="post">
            <input id="nombre" class="controls" type="text" name="nombre" placeholder="Nombre" required />
            <input class="controls" type="text" name="material" placeholder="Material" required />
            <input class="controls" type="text" name="dimensiones" placeholder="Dimensiones" required />
            <input class="controls" type="number" name="precio" placeholder="Precio" required />
            <input class="controls" type="text" name="categoria" placeholder="Categoría" required />
            <input class="controls" type="url" name="imagen" placeholder="Imagen (URL)" required />
            <input class="buttons" type="submit" value="Agregar" />
        </form>
    </section>

    <br>
    <br>

    <section class="table_header">
        <h1>Productos del catálogo</h1>
    </section>

    <section class="search-bar">
        <input type="text" id="searchInput" onkeyup="filterTable()" placeholder="Buscar productos">
    </section>

    <section class="table_body">
        <?php
        include("Conexion.php");
        $sql = mysqli_query($con, "SELECT * FROM productos");
        ?>
        <table id="productos-table">
            <thead>
            <tr>
                <th>ID <span class="icon-arrow">&UpArrow;</span></th>
                <th>Nombre <span class="icon-arrow">&UpArrow;</span></th>
                <th>Material <span class="icon-arrow">&UpArrow;</span></th>
                <th>Dimensiones <span class="icon-arrow">&UpArrow;</span></th>
                <th>Precio <span class="icon-arrow">&UpArrow;</span></th>
                <th>Categoría <span class="icon-arrow">&UpArrow;</span></th>
                <th>Imagen <span class="icon-arrow">&UpArrow;</span></th>
                <th>Acciones</th>
            </tr>
            </thead>
            <tbody id="productos-table-body">
            <?php
            while ($row = mysqli_fetch_array($sql)) { ?>
                <tr>
                    <td><?php echo $row['Id'] ?></td>
                    <td><?php echo $row['Nombre'] ?></td>
                    <td><?php echo $row['Material'] ?></td>
                    <td><?php echo $row['Dimensiones'] ?></td>
                    <td><?php echo $row['Precio'] ?></td>
                    <td><?php echo $row['Categoria'] ?></td>
                    <td><img src="<?php echo $row['Imagen'] ?>" alt="Imagen"></td>
                    <td>
                        <form method="post" class="edit-form" style="display: none;">
                            <input type="hidden" name="id" value="<?php echo $row['Id']; ?>">
                            <input type="text" name="nombre" value="<?php echo $row['Nombre']; ?>">
                            <input type="text" name="material" value="<?php echo $row['Material']; ?>">
                            <input type="text" name="dimensiones" value="<?php echo $row['Dimensiones']; ?>">
                            <input type="number" name="precio" value="<?php echo $row['Precio']; ?>">
                            <input type="text" name="categoria" value="<?php echo $row['Categoria']; ?>">
                            <input type="url" name="imagen" value="<?php echo $row['Imagen']; ?>">
                            <button type="button" class="update-btn" onclick="updateProduct(this)">Actualizar</button>
                            <button type="button" class="cancel-btn" onclick="cancelEdit(this)">Cancelar</button>
                        </form>
                        <button class="editar" onclick="showEditForm(this)">Editar</button>
                        <form method="post" action="Eliminar_Producto.php">
                            <input type="hidden" name="id" value="<?php echo $row['Id']; ?>">
                            <button type="submit" class="eliminar" name="eliminar">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php } ?>
            </tbody>
        </table>
    </section>
</main>

<footer>
      <div class="container">
        <p>&copy; Tu Amigo Amigurumi. Todos los derechos reservados.</p>
        <ul>
          <li>
            <a href="https://www.facebook.com/amigurumiscrochetgdl"
              ><i class="fab fa-facebook-f"></i
            ></a>
          </li>
          <li>
            <a href="https://www.instagram.com/tuamigoamigurumi/?hl=es"
              ><i class="fab fa-instagram"></i
            ></a>
          </li>
        </ul>
      </div>
    </footer>

<script>
    function showEditForm(button) {
        var editForm = button.parentElement.querySelector('.edit-form');
        editForm.style.display = 'block';
    }

    function cancelEdit(button) {
        var editForm = button.parentElement;
        editForm.style.display = 'none';
    }

    function updateProduct(button) {
        var form = button.parentElement;
        var id = form.querySelector('input[name="id"]').value;
        var nombre = form.querySelector('input[name="nombre"]').value;
        var material = form.querySelector('input[name="material"]').value;
        var dimensiones = form.querySelector('input[name="dimensiones"]').value;
        var precio = form.querySelector('input[name="precio"]').value;
        var categoria = form.querySelector('input[name="categoria"]').value;
        var imagen = form.querySelector('input[name="imagen"]').value;

        var row = form.parentElement.parentElement;
        row.querySelector('td:nth-child(2)').textContent = nombre;
        row.querySelector('td:nth-child(3)').textContent = material;
        row.querySelector('td:nth-child(4)').textContent = dimensiones;
        row.querySelector('td:nth-child(5)').textContent = precio;
        row.querySelector('td:nth-child(6)').textContent = categoria;
        row.querySelector('td:nth-child(7) img').src = imagen;

        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                console.log("Producto actualizado en la base de datos");
            }
        };
        xhttp.open("POST", "editar_producto.php", true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send("id=" + id + "&nombre=" + nombre + "&material=" + material + "&dimensiones=" + dimensiones + "&precio=" + precio + "&categoria=" + categoria + "&imagen=" + imagen);

        form.style.display = 'none';
    }

    function filterTable() {
        var input = document.getElementById('searchInput');
        var filter = input.value.toUpperCase();
        var table = document.getElementById('productos-table');
        var tbody = table.getElementsByTagName('tbody');
        var tr = tbody[0].getElementsByTagName('tr');

        for (var i = 0; i < tr.length; i++) {
            var td = tr[i].getElementsByTagName('td');
            var found = false;
            for (var j = 0; j < td.length; j++) {
                var txtValue = td[j].textContent || td[j].innerText;
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    found = true;
                    break;
                }
            }
            if (found) {
                tr[i].style.display = '';
            } else {
                tr[i].style.display = 'none';
            }
        }
    }
</script>

</body>
</html>