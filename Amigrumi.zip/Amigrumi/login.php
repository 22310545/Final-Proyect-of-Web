<?php 
include "Conexion.php";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Obtiene los datos del formulario
    $usuario = $_POST['usuario'];
    $contrasena = $_POST['contrasena']; 

    // Realiza la consulta para verificar las credenciales del admin
    $query_admin = "SELECT * FROM administradores WHERE Correo='$usuario' AND Contraseña='$contrasena'";
    $result_admin = mysqli_query($con, $query_admin);

    if(mysqli_num_rows($result_admin) == 1){
        // Inicia la sesión para el administrador
        session_start();
        $_SESSION['admin'] = true;
        header("Location: Admin.php");
        exit;
    } else {
        // Si las credenciales no corresponden a un admin, procede con la verificación de usuario normal
        $query_user = "SELECT * FROM usuario WHERE CorreoUsuario='$usuario' AND ContraseñaUsuario='$contrasena'";
        $result_user = mysqli_query($con, $query_user);

        if(mysqli_num_rows($result_user) == 1){
            // Inicia la sesión para el usuario normal
            session_start();
            $_SESSION['usuario'] = $usuario;
            header("Location: InicioUsuario.php");
            exit;
        } else {
            // Si las credenciales son incorrectas, redirige al usuario a la página de inicio de sesión con un mensaje de error
            header("Location: login.html?error=credenciales_incorrectas");
            exit;
        }
    }
}
?>                             