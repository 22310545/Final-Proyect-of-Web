<?php
    include "Conexion.php";

    $nombre=$_POST['nombre'];
    $apellido=$_POST['apellidos'];
    $FechNac=$_POST['FechNac'];
    $pais=$_POST['pais'];
    $direccion=$_POST['direccion'];
    $correo=$_POST['correo'];       
    $pass=$_POST['nucontrasena'];
    $tel=$_POST['telefono'];

    $sql=mysqli_query ($con, "INSERT INTO usuario(IdUsuario,NombreUsuario,ApellidoUsuario,FechaNacimiento,PaisUsuario,DireccionUsuario,CorreoUsuario,ContraseñaUsuario,TelefonoUsuario)
    VALUES(0,'$nombre','$apellido', '$FechNac','$pais','$direccion','$correo','$pass','$tel')");

    if($sql){
        header("Location: Index.html");
    }else{
        echo "Error al registrar";
    }
?>