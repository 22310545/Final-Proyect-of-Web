<?php
    include("Conexion.php");

    if(isset($_POST['actualizar'])) {
        $id = $_POST['id'];
        $nombre = $_POST['nombre'];
        $material = $_POST['material'];
        $dimensiones = $_POST['dimensiones'];
        $precio = $_POST['precio'];
        $categoria = $_POST['categoria'];
        $imagen = $_POST['imagen'];

        $query = "UPDATE productos SET Nombre='$nombre', Material='$material', Dimensiones='$dimensiones', Precio='$precio', Categoria='$categoria', Imagen='$imagen' WHERE Id='$id'";
        mysqli_query($con, $query);

        // Redireccionar a Admin.php después de actualizar
        header("Location: Admin.php");
        exit();
    }
?>