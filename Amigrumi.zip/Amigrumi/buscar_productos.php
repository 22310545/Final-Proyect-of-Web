<?php
include "Conexion.php";

if (isset($_GET['query'])) {
    $query = $_GET['query'];
    // Verifica si la consulta es un número (para buscar por ID) o una cadena (para buscar por nombre)
    if (is_numeric($query)) {
        $sql = "SELECT * FROM productos WHERE Id = $query"; // Busca por ID
    } else {
        $sql = "SELECT * FROM productos WHERE Nombre LIKE '$query%'"; // Busca por nombre
    }
    $result = mysqli_query($con, $sql);

    // Genera el HTML de las filas de la tabla de productos
    while ($row = mysqli_fetch_array($result)) {
        echo '<tr>';
        echo '<td>' . $row['Id'] . '</td>';
        echo '<td>' . $row['Nombre'] . '</td>';
        echo '<td>' . $row['Material'] . '</td>';
        echo '<td>' . $row['Dimensiones'] . '</td>';
        echo '<td>' . $row['Precio'] . '</td>';
        echo '<td>' . $row['Categoria'] . '</td>';
        echo '<td>' . $row['Imagen'] . '</td>';
        echo '</tr>';
        
    }
} else {
    // Si no se proporcionó ninguna consulta, devolver un mensaje de error
    echo 'No se proporcionó ningún término de búsqueda';
}
?>